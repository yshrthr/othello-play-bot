# AI_Othello
Develop a bot to play the Othello game in C++
